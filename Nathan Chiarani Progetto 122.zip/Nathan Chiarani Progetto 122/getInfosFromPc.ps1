param([switch]$help, [string]$option, [string]$question1)

if($option -eq $null -and $question1 -eq $null){
	write-host "`nUse -help for a tutorial`n"
}else{
	if($help){
		#GENERAL
		write-host "`nIT WORKS WITH ONLY ENGLISH POWERSHELL`n"
		write-host "SYNTAX: `n`t.\Script.ps1 option argument,argument [-help] `n"
		write-host "EXAMPLE: `n`t.\Script.ps1 'Network' 'Give me ipv4 address' `n"
		write-host "SCOPES: `n`tThere are 4 options: Network, Hardware, Pc, Other`n"
		#NETWORK
		write-host "NETWORK OPTIONS: `n"
		write-host "`tEthernet `t`t Shows the Ethernet informations"
		write-host "`tIPv4 `t`t`t Shows the IPv4 address"
		write-host "`tIPv6 `t`t`t Shows the IPv6 address"
		write-host "`tMAC Address `t`t Shows the MAC address"
		write-host "`tSubnet Mask `t`t Shows the Subnet mask address"
		write-host "`tDefault gateway `t Shows the Default Gateway address"
		write-host "`tDNS Server `t`t Shows the DNS Server address"
		write-host "`tDHCP Server `t`t Shows the DHCP Server address"
		write-host "`tNetBIOS `t`t Shows the NetBIOS informations"
		write-host "`tTCP Connections `t Shows the TCP Connections informations"
		#HARDWARE
		write-host "`nHARDWARE OPTIONS: `n"
		write-host "`tCPU `t `t`t Shows the CPU informations"
		write-host "`tGPU `t`t `t Shows the GPU informations"
		write-host "`tNetwork card `t`t Shows the Network card informations"
		write-host "`tAudio card `t`t Shows the Audio card informations"
		write-host "`tStorage `t`t Shows the Storage informations"
		write-host "`tRAM `t`t`t Shows the RAM informations"
		write-host "`tMotherboard `t`t Shows the Motherboard informations"
		write-host "`tPhysical Disk `t`t Shows the Physical Disk informations"
		#PC
		write-host "`nPC OPTIONS: `n"
		write-host "`tUsers `t`t`t Shows the users"
      	write-host "`tOwner `t`t`t Shows the owner"
		write-host "`tSO `t`t`t Shows the SO informations"
		write-host "`tEdition `t`t Shows the Windows edition"
		write-host "`tVersion `t`t Shows the Windows version"
		write-host "`tProduct `t`t Shows the Windows product"
		write-host "`tWindows product Id `t Shows the Windows product id"
		write-host "`tLanguage `t`t Shows the Language informations"
		write-host "`tArchitecture `t`t Shows the Architecture informations"
		write-host "`tSystem Status `t`t Shows the System status informations"
		#OTHER
		write-host "`nOTHER OPTIONS: `n"
		write-host "`tBIOS `t`t`t Shows the BIOS informations"
		write-host "`tStorage `t`t Shows the Storage informations"
		write-host "`tLocal Time `t`t Shows the Local Time informations"
		write-host "`tLogon `t`t`t Shows the logon informations"
		write-host "`tDesktop `t`t Shows the Desktop informations"
		write-host "`tHotifx `t`t `t Shows the Hotfixes informations"
		write-host "`tService Status `t`t Shows the Service status informations"
		write-host "`tSystem Directory `t Shows the System directory informations"
		write-host "`tSystem Drive`t`t Shows the System Drive informations"
		write-host "`tDisk `t`t`t Shows the Disk informations"
		write-host "`tPartition `t`t Shows the Partitions informations"
	}else{ 
		$question = $question1.split(" ")
		if($option -ieq "Network"){
			if($question -ilike "IPv4"){
				ipconfig | Select-String "IPv4"
			}elseIf($question -ilike "IPv6"){
				ipconfig | Select-String "IPv6"
			}elseIf($question -ilike "MAC"){
				ipconfig /all | Select-String "MAC"
			}elseIf($question -ilike "Ethernet" -or $question -ilike "all"){
				ipconfig /all 
			}elseIf($question -ilike "Subnet"){
				ipconfig /all | Select-String "Subnet Mask"
			}elseIf($question -ilike "gateway"){
				ipconfig /all | Select-String "Gateway"
			}elseIf($question -ilike "DNS"){
				ipconfig /all | Select-String "Server DNS"
			}elseIf($question -ilike "DHCP"){
				ipconfig /all | Select-String "Server DHCP"
			}elseIf($question -ilike "BIOS"){
				ipconfig /all | Select-String "NetBIOS"
			}elseIf($question -ilike "tcp"){
				Get-NetTCPConnection
			}else{
				write-host "`nCOULD NOT FIND ANYTHING LIKE THAT IN NETWORK INFOS: $question`n"
			}
		}elseIf($option -ieq "Hardware"){
			if($question -ilike "cpu"){
				Get-ComputerInfo -Property "*processor*"
			}elseIf($question -ilike "video" -or $question -ilike "gpu"){
				Get-WmiObject win32_VideoController
			}elseIf($question -ilike "sound" -or $question -ilike "audio"){
				Get-CimInstance -ClassName Win32_SoundDevice
			}elseIf($question -ilike "ram"){
				Get-WmiObject Win32_PhysicalMemory 
			}elseIf($question -ilike "storage"){
				Get-CimInstance -ClassName Win32_LogicalDisk
			}elseIf($question -ilike "mb" -or $question -ilike "motherboard"){
				Get-WmiObject win32_baseboard | Format-List Product,Manufacturer,SerialNumber,Version
			}elseIf($question -ilike "network"){
				Get-NetAdapter
			}elseIf($question -ilike "Physical"){
				Get-PhysicalDisk
			}else{
				write-host "`nCOULD NOT FIND ANYTHING LIKE THAT IN HARDWARE INFOS: $question`n"
			}
		}elseIf($option -ieq "PC"){
			if($question -ilike "version" -or $question -ilike "edition"){
				Get-ComputerInfo -Property "OSDisplayVersion","Windows*version"
			}elseIf($question -ilike "so" -or $question -ilike "info"){
				Get-CimInstance -ClassName Win32_OperatingSystem
			}elseIf($question -ilike "product" -or $question -ilike "model"){
				Get-CimInstance -ClassName Win32_ComputerSystem
				Get-ComputerInfo -Property "WindowsProductId"
			}elseIf($question -ilike "owner"){
				Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -Property "*owner*"
			}elseIf($question -ilike "user"){
				Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object -Property "*user*"
				Get-CimInstance -ClassName Win32_ComputerSystem -Property UserName
			}elseIf($question -ilike "id"){
				Get-ComputerInfo -Property "WindowsProductId"
			}elseIf($question -ilike "language"){
				Get-WinUserLanguageList
			}elseIf($question -ilike "Architecture"){
				(Get-WmiObject Win32_OperatingSystem).OSArchitecture
			}elseIf($question -ilike "status"){
				Get-CimInstance -Class CIM_OperatingSystem
			}else{
				write-host "`nCOULD NOT FIND ANYTHING LIKE THAT IN PC INFOS: $question`n"
			}
		}elseIf($option -ieq "Other"){
			if($question -ilike "bios"){
				Get-CimInstance -ClassName Win32_BIOS | Select-Object -ExcludeProperty "CIM*"
			}elseIf($question -ilike "storage"){
				Get-CimInstance -ClassName Win32_LogicalDisk
			}elseIf($question -ilike "time"){
				Get-CimInstance -ClassName Win32_LocalTime
			}elseIf($question -ilike "logon"){
				Get-CimInstance -ClassName Win32_LogonSession
			}elseIf($question -ilike "desktop"){
				Get-CimInstance -ClassName Win32_Desktop | Select-Object -ExcludeProperty "CIM*"
			}elseIf($question -ilike "hotfix" -or $question -ilike "hotfixes"){
				Get-CimInstance -ClassName Win32_QuickFixEngineering -Property HotFixID
			}elseIf($question -ilike "service" -or $question -ilike "status"){
				Get-CimInstance -ClassName Win32_Service | Format-Table -Property Status,Name,Displayname -AutoSize -Wrap
			}elseIf($question -ilike "directory" -or $question -ilike "system" -or $question -ilike "system directory"){
				Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object -Property System*Directory
			}elseIf($question -ilike "drive" -or $question -ilike "system drive"){
				Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object -Property System*Directory
			}elseIf($question -ilike "disk" -or $question -ilike "volume"){
				Get-Volume
			}elseIf($question -ilike "partition"){
				Get-Partition
			}else{
				write-host "`nCOULD NOT FIND ANYTHING LIKE THAT IN PC INFOS: $question`n"
			}
		}else{
				write-host "`nIF YOU DON'T KNOW HOW TO USE THIS SCRIPT `nUSE .\getInfoFromPc.ps1 -help`n"
		}
	}
}

	